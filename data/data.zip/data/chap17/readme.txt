Data files
----------

melampyr.xls - Excel file with original data and with calculations
               needed to adjust the length of arrows for explanatory
               variables (plant characters)

mel_char.dta - Primary data (measurements on plants)

mel_clas.dta - Classification of plants into differentiated taxa


Project files
-------------

mel_cva.con  - CVA project file

mel_cva2.con - this is a "fake" project, used for creating CanoDraw
               project, using the mel_cva2.sol with adjusted
               BipE scores for explanatory variables

mel_rda.con  - RDA project. It is needed to calculate adjustment
               ratios for environmental variables BipE scores


.sol and .log files have the same names as the corresponding projects

