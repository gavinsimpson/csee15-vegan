Files
-----

ordin.xls - illustrates the weighted averaging algorithm used 
            in most software implementations of correspondence analysis 
            method. Its contents is described in section 3.5
