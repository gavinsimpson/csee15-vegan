Data files
----------

tatry.xls - Data from releves (ordinal transformation of the Br.Bl. scale)
            on elevational gradient in Tatras (Leps et al. 1985).
 Sheet TATRY   = species data; 
 Sheet tatenv  = elevation of the releve; 
 Sheet tatrand = randomly generated environmental data.
            File contains macro for generating random data
tatry.spe - species data in condensed CANOCO format
tatrand.env - randomly generated environmental data in full CANOCO format


Projects
--------

tatrand.con - CCA with forward selection of (randomly generated) variables

.sol and .log files have the same names as the corresponding projects
 