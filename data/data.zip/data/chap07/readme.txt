Data files
----------

tatry.xls    - Data from releves (ordinal transformation of the 
               Br.Bl. scale) on elevational gradient in Tatras 
               (Leps et al. 1985).
   Sheet TATRY   = species data; 
   Sheet tatenv  = elevation of the releve; 
   Sheet tatrand = randomly generated environmental data.
               File contains macro for generating random data

tatry.spe    - species data in condensed CANOCO format 
               (The same data as in tatry.xls)

tatry.sta    - species data in Statistica format. 
               (The same data as in tatry.xls).

tatry.env    - explanatory variable (altitude) in Canoco data format


Project files
-------------

tatrydca.con - Canoco project file for a DCA

tatrydca.cdw - corresponding CanoDraw project file


Other files
-----------

tatrydca.sol - analysis results for TATRYDCA.CON project

tatrydca.log - analysis log for TATRYDCA.CON project

tatry.prt    - text file with TWINSPAN output log
