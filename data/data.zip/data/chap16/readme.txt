Data files
----------

scale.xls    - original data in Excel spreadsheet.

scale_sp.dta - species data in Canoco format

scale_en.env - environmental variables (describing sampling design,
               i.e. the spatial scale), in Canoco format


Project files
-------------

cray_tot.con - PCA, summarizing total variability in crayfish data

crayf_ws.con - RDA, summarizing variability on watersheds level

crayf_st.con - partial RDA, summarizing variability on streams level

crayf_re.con - partial RDA, summarizing variability on reaches level

crayf_ru.con - partial RDA, summarizing variability on runs level


.sol and .log files have the same names as the corresponding projects
