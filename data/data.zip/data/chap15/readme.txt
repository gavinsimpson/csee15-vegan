Data files
----------

ohraz.xls    - original data, contains sheets SEEDLSPE and SEEDLENV, 
               with species and environmental (design) data, 
               and a sheet with data for Statistica

ohraz.spe    - species data in condensed CANOCO format

ohraz.env    - environmental (design) data in full CANOCO format 
               [P1 - P24: plot identifiers]

ohrazenv.sta - file with number of species in plots in particular year, 
               in Statistica format (for repeated measurements ANOVA)

ohrazprc.xls - Excel file with data modified for purposes of
               PRC analyses (different coding of treatments, for example)

prc_spe.dta  - species data for PRC analyses

prc_env.dta  - environmental data for PRC analyses

prc_cov.dta  - covariate data for PRC analyses


Project files
-------------

OhrC1.con - OhrC5.con: analyses C1 - C5, as described in table 15-2.

ohrazprc.con  - PRC analysis

ohrzprc.con   - another PRC analysis, with another treatment
                taken as the "control" (reference) treatment

ohrazprc.cdw  - CanoDraw project corresponding to ohrazprc.con 

ohrzprc.cdw   - CanoDraw project corresponding to ohrzprc.con


Other files
-----------

.sol and .log files have the same names as the corresponding projects


*.cdg         - CanoDraw graphs used to create PRC diagrams in chapter 15
