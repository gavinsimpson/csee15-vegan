Data files
----------

bird_spe.dta - species (bird community) data in Canoco format

bird_env.dta - explanatory (environmental) data in Canoco format

birds.xls    - Excel spreadsheet with original data


Project files
-------------

dca.con      - Canoco project for DCA on birds data

pca.con      - Canoco project for PCA on birds data

rda1.con     - Canoco project for RDA with altitude as the only 
               explanatory variable and corresponding permutation test

rda2.con     - Canoco project for partial RDA, summarising the effect
               of other explanatory variables after accounting for
               altitudinal differences, with corresponding permutation test

pca.cdw      - CanoDraw project based on PCA.CON

rda1.cdw     - CanoDraw project based on RDA1.CON

rda2.cdw     - CanoDraw project based on RDA2.CON


Other files
-----------

.sol and .log files have the same names as the corresponding projects

fig11-3.cdg  - CanoDraw graph based on the PCA project

fig11-4.cdg  - CanoDraw graph based on the RDA1 project

fig11-5.cdg  - CanoDraw graph based on the RDA2 project



