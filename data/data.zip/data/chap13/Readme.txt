Data files
----------

fertil.xls   - original data, contains sheets FERTSPE and FERTENV, 
               with species and environmental (design) data

fertil.spe   - species data in condensed CANOCO format

fertil.env   - environmental (design) data in full CANOCO format

fertenv.sta  - the dose, cover and number of species in Statistica 
               format for univariate analyses

Project files
-------------

fertdca.con  - DCA of species data, with passive projection of 
               environmental data

fertrdan.con - RDA with cover and dose as environmental variables 
               (no standardisation by samples)

fertrdas.con - RDA with cover and dose as environmental variables 
               (standardisation by sample norm)

fertrda1.con - partial RDA (no standardisation by samples), 
               cover=environmental, dose=covariable

fertrda2.con - partial RDA (no standardisation by samples), 
               dose=environmental, cover=covariable

.sol and .log files have the same names as the corresponding projects

