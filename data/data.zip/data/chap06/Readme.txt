Data files
----------

persim.xls   - file containing macro for calculation of matrix 
               of percentage similarities (both from original, 
               and from standardised by sample total data). The 
               data sheet contains data on species composition of
               14 releves on an elevational gradien 
               (the same as in tatry.xls)

tatry.sta    - data on species composition of 14 releves on an 
               elevational gradient in Statistica format. 
               (The same data are also in tatry.xls file).

tatry.xls    - Excel spreadsheet with the original data

tatry.spe    - species (plant community composition) data in
               Canoco format

tatry.env    - environmental data (sample altitude) in Canoco format

tat_pcoa.dta - sample scores from PCoA, calculated by PrCoord program
               and stored in Canoco format data file

Project files
-------------

tat_pcoa.con - Canoco project file for presenting results of PCoA
               (calculated with PrCoord), using CanoDraw for Windows
               program

tat_pcoa.cdw - corresponding CanoDraw project file


Other files
-----------

pcoa.cdg     - diagram from PCoA method, calculated with PrCoord
               and Canoco for Windows

tat_pcoa.sol - analysis results for the TAT_PCOA.CON project

tat_pcoa.log - analysis log for TAT_PCOA.CON project
