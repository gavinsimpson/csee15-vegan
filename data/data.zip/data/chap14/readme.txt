Data files
----------

seedl.xls    - original data, contains sheets SEEDLSPE and SEEDLENV, 
               with species and environmental (design) data, 
               and sheet for Statistica
seedl.spe    - species data in condensed CANOCO format
seedl.env    - environmental (design) data in full CANOCO format
seedlenv.sta - the treatment, block and number of seedlings in 
               Statistica format for univariate analyses

Project files
-------------

seedldca.con - DCA of species data

seedrda1.con - RDA, no standardisation by samples, 
               scaling focused on interspecies correlations

seedrda2.con - RDA, no standardisation by samples, 
               scaling focused on intersample distances

seedrda3.con - RDA, standardisation by sample norm, 
               scaling focused on interspecies correlations

Note that we decided to use non-restricted permutations in RDA. 
The permutations within blocks are the other possibility.

.sol and .log files have the same names as the corresponding projects

