Data files
----------

Meadows.xls  - original data, both species and environmental, 
               in MS Excel format, in species data are the vascular 
               plant taxa highlighted

Meadows.spe  - species data in CANOCO condensed format

Meadows.env  - environmental data in CANOCO full format

Meadows.cov  - SamE scores on the first axis, used as a covariable 
               for testing significance of the second CCA axis 
               (in meadcca2.con project)

Meadows2.cov - SamE scores on the first two axes, used as covariables 
               for testing significance of the third CCA axis
               (in meadcca3.con project)

Project files
-------------

MeadDCA.con  - DCA with passive projection of environmental data

MeadCCA1.con - CCA with all the environmental variables

MeadCCA2.con - CCA, testing the significance of the second CCA axis

MeadCCA3.con - CCA, testing the significance of the third axis

MeadCCA4.con - CCA with automatic forward selection, used to generate 
               Table 12-1 (use FS summary)


Other files
-----------

.sol and .log files have the same names as the corresponding projects

meadows.prt  - text file with TWINSPAN output log
 